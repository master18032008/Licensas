-- 1135690's Lua and Manifest Created by Hubcap Manifest
-- Unpacking
-- Created: October 31, 2025 at 14:01:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1135690) -- Unpacking
-- MAIN APP DEPOTS
addappid(1135691, 1, "32dcfa1767b00d316eaa45a92c3f4a387f711be0c45ff63508a6b39e233a5f7f") -- Unpacking Win
setManifestid(1135691, "2844231876907157130", 985073004)
addappid(1135692, 1, "ee27dc6438ed5a6ef0d323a4ae2863cd1ec157646a31b5287665085f1979b255") -- Unpacking OSX
setManifestid(1135692, "555501945044545179", 989398527)
addappid(1135693, 1, "b5fd7ce1c961510f9ffc7db6ec2bd0e67bc2056c9c60ffa506c10c09e801ac97") -- Unpacking Linux
setManifestid(1135693, "7944198618826444064", 968276887)